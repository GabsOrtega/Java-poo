package aula04b;

public class Aula04b {

    public static void main(String[] args) {
       Curso c = new Curso();
       Curso c1 = new Curso("Ciência da Computação", 100, "3f", 400);
       
       c.cadastraCurso("Biomedicina", 53, "3M", 589);
       c.imprimeDados();
       System.out.println("Mensalidade Total: " + c.calculaTotalMensalidade());
       c1.imprimeDados();
       System.out.println("Mensalidade Total: " + c1.calculaTotalMensalidade());
    }
    
}
