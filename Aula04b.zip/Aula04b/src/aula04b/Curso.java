
package aula04b;

public class Curso {
    String nome;
    int quantidadedealunos;
    String turma;
    float mensalidade;
    
    public Curso(){}
    
    public Curso(String n, int q, String t, float m){
        this.nome = n;
        this.quantidadedealunos = q;
        this.turma = t;
        this.mensalidade = m;
    }
    
    void cadastraCurso(String n, int q, String t, float m){
        this.nome = n;
        this.quantidadedealunos = q;
        this.turma = t;
        this.mensalidade = m;
    }
    
    void imprimeDados(){
        System.out.println("---- Curso ----");
        System.out.println("Nome: " + this.nome);
        System.out.println("Quantidade de alunos: " + this.quantidadedealunos);
        System.out.println("Turma: " + this.turma);
        System.out.println("Mensalidade: " + this.mensalidade);
    }
    
    float calculaTotalMensalidade() {
        return this.mensalidade * this.quantidadedealunos;
    }
    
    
}
