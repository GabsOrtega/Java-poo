
package aula03;


public class Aula03 {


    public static void main(String[] args) {
       Triangulo t = new Triangulo();
       Triangulo t1 = new Triangulo(25.5f, 20.2f);
       Data d = new Data();
       Data d1 = new Data(02, 04, 2024);
       
       t.calculaArea();
       t.imprimeDados();
       
       t1.calculaArea();
       t1.imprimeDados();
       
       d.cadastraDados();
       d.imprimeData();
       
       d1.imprimeData();
               
       
       
       
       
    }
    
}
