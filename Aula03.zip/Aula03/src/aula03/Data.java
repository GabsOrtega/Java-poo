
package aula03;

import java.util.Scanner;


public class Data {
   int dia, mes, ano;
    
   public Data(){
       
   }
   
   public Data(int d, int m, int a) {
       this.dia = d;
       this.mes = m;
       this.ano = a;
   }
   
   public void cadastraDados() {
       Scanner teclado = new Scanner(System.in);
       
       System.out.println("Digite o dia");
       this.dia = teclado.nextInt();
       
       System.out.println("Digite o mês");
       this.mes = teclado.nextInt();
       
       System.out.println("Digite o ano");
       this.ano = teclado.nextInt();
       
   }
   
   public void imprimeData(){
       System.out.println(this.dia + "/" + this.mes + "/" + this.ano);
   }
}
