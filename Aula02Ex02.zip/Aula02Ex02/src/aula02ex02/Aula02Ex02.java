
package aula02ex02;

import java.util.Scanner;


public class Aula02Ex02 {


    public static void main(String[] args) {
      Produto prod = new Produto();
      
      Scanner teclado = new Scanner(System.in);
      
      String marca, fabricante, codBarras;
      float preco;
      
      System.out.println("Digite a marca do Produto: ");
      marca = teclado.nextLine();
      
      System.out.println("Digite o fabricante do Produto: ");
      fabricante = teclado.nextLine();
      
      System.out.println("Digite o código de barras do Produto: ");
      codBarras = teclado.nextLine();
      
      System.out.println("Digite o preço do Produto: ");
      preco = teclado.nextFloat();
      
      Produto prod2 = new Produto(marca, fabricante, codBarras, preco);
      
      System.out.println("Dados do primeiro produto: ");
      System.out.println("Marca: " + prod.marca);
      System.out.println("Fabricante: " + prod.fabricante);
      System.out.println("Código de barras: " + prod.cod_barras);
      System.out.println("Preço: " + prod.preco);
      
      System.out.println("\nDados do segundo produto: ");
      System.out.println("Marca: " + prod2.marca);
      System.out.println("Fabricante: " + prod2.fabricante);
      System.out.println("Código de barras: " + prod2.cod_barras);
      System.out.println("Preço: " + prod2.preco);
        
    }
    
}
