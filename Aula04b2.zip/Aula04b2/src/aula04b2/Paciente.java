package aula04b2;

public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    int anoNascimento;
    String profissao;
    
    public Paciente(){}
    
    public Paciente(String n){
        this.nome = n;
    }
    
    void cadastraDados(String n, String rg, String e, String t, int a, String p) {
        this.nome = n;
        this.rg = rg;
        this.endereco = e;
        this.telefone = t;
        this.anoNascimento = a;
        this.profissao = p;
    }
    
    void imprimeDados(){
        System.out.println("---- Paciente ----");
        System.out.println("Nome: " + this.nome);
        System.out.println("RG: " + this.rg);
        System.out.println("Endereço: " + this.endereco);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Ano de Nascimento: " + this.anoNascimento);
        System.out.println("Profissão: " + this.profissao);
    }
    
    int calculaIdade(int anoAtual) {
        return anoAtual - this.anoNascimento;
    }
}
