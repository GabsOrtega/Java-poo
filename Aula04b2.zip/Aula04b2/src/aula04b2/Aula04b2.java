package aula04b2;

public class Aula04b2 {

    public static void main(String[] args) {
        Paciente p = new Paciente();
        Paciente p1 = new Paciente("Orteguinhas");
        
        p.cadastraDados("Gabriel", "00.000.000-0", "Rua josé antonio", "11 90000-0000", 2004, "Desenvolvedor");
        p.imprimeDados();
        System.out.println("Idade: " + p.calculaIdade(2024));
        
        p1.imprimeDados();
    }
    
}
