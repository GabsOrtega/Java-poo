
package aula0201;

public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    String dataNascimento;
    String profissao;
    
    public Paciente(){}
    
    public Paciente(String nome){
        this.nome = nome;
    }
}
