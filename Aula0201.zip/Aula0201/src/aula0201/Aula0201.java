/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula0201;
import javax.swing.JOptionPane;
public class Aula0201 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Paciente p = new Paciente();
        Paciente p1 = new Paciente("Ortega");
        
        p.nome = JOptionPane.showInputDialog("Digite o nome do primeiro Paciente");
        p.rg = JOptionPane.showInputDialog("Digite o RG do primeiro Paciente");
        p.endereco = JOptionPane.showInputDialog("Digite o endereço do primeiro Paciente");
        p.telefone = JOptionPane.showInputDialog("Digite o telefone do primeiro Paciente");
        p.dataNascimento = JOptionPane.showInputDialog("Digite a data de nascimento do primeiro Paciente");
        p.profissao = JOptionPane.showInputDialog("Digite a profissao do primeiro Paciente");
        
        p1.rg = JOptionPane.showInputDialog("Digite o RG do segundo Paciente");
        p1.endereco = JOptionPane.showInputDialog("Digite o endereço do segundo Paciente");
        p1.telefone = JOptionPane.showInputDialog("Digite o telefone do segundo Paciente");
        p1.dataNascimento = JOptionPane.showInputDialog("Digite a data de nascimento do segundo Paciente");
        p1.profissao = JOptionPane.showInputDialog("Digite a profissao do segundo Paciente");
        
        System.out.println("--- Paciente 1 ---");
        System.out.println("Nome: " + p.nome);
        System.out.println("RG: " + p.rg);
        System.out.println("Endereço" + p.endereco);
        System.out.println("Telefone: " + p.telefone);
        System.out.println("Data de Nascimento: " + p.dataNascimento);
        System.out.println("Profissão: " + p.profissao);
        
        
        System.out.println("\n--- Paciente 2 ---");
        System.out.println("Nome: " + p1.nome);
        System.out.println("RG: " + p1.rg);
        System.out.println("Endereço" + p1.endereco);
        System.out.println("Telefone: " + p1.telefone);
        System.out.println("Data de Nascimento: " + p1.dataNascimento);
        System.out.println("Profissão: " + p1.profissao);
        
        
        
       
        

    }
    
}
