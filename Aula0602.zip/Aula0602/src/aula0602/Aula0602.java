package aula0602;

import javax.swing.JOptionPane;

public class Aula0602 {


    public static void main(String[] args) {
        
        String analistaNome, analistaMatricula;
        
        analistaNome = JOptionPane.showInputDialog("Digite o nome do analista");
        
        analistaMatricula = JOptionPane.showInputDialog("Digite o número de mátricula do analista");
        
        String arrayS = JOptionPane.showInputDialog("Digite a quantidade de horas do analista (Para adicionar mais de um valor de espaço entre as horas)"); 
        
        String[] strArray = arrayS.split(" "); 
        
        float[] analistaValorHora = new float[strArray.length]; 
        
        for (int i = 0; i < strArray.length; i++) {
            analistaValorHora[i] = Float.parseFloat(strArray[i]);
        }
        
        Analista a1 = new Analista(analistaNome, analistaMatricula, arrayS);
    }
    
}
