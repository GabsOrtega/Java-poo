
package aula02;

import java.util.Scanner;

public class Aula02 {

    public static void main(String[] args) {
       String nome;
       Scanner teclado = new Scanner(System.in);
       System.out.println("Digite o seu nome");
       nome = teclado.nextLine();
       
       Paciente p = new Paciente();
       Paciente p1 = new Paciente(nome);
       
       System.out.println("Dados do primeiro paciente: ");
       System.out.println("Nome: " + p.nome);
       System.out.println("RG: " + p.rg);
       System.out.println("Endereço " + p.endereco);
       System.out.println("Telefone" + p.telefone);
       System.out.println("Data de Nascimento: " + p.dataNascimento);
       System.out.println("Profissão: " + p.profissao);
       
       System.out.println("\n");
       System.out.println("Dados do segundo paciente: ");
       System.out.println("Nome: " + p1.nome);
       System.out.println("RG: " + p1.rg);
       System.out.println("Endereço " + p1.endereco);
       System.out.println("Telefone" + p1.telefone);
       System.out.println("Data de Nascimento: " + p1.dataNascimento);
       System.out.println("Profissão: " + p1.profissao);
       
       
    }
    
}
