
package aula0502;


public class Triangulo {
    private double base;
    private double altura;
    
    public Triangulo(){}
    
    public Triangulo(double base, double altura){
        this.base = base;
        this.altura = altura;
    }

    double getBase() {
        return this.base;
    }

    void setBase(double base) {
        this.base = base;
    }

    double getAltura() {
        return this.altura;
    }

    void setAltura(double altura) {
        this.altura = altura;
    }
    
    double calculaArea() {
        double area = (this.base * this.altura) / 2;
        return area;
    }
    
    void imprimeDados(){
        System.out.println("---- Triângulo ----");
        System.out.println("Base: " + this.getBase());
        System.out.println("Altura: " + this.getAltura());
        System.out.println("Área: " + this.calculaArea(this.getBase(), this.getAltura()));
    }
    
    
}
