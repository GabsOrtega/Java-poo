
package aula0502;

public class Aula0502 {


    public static void main(String[] args) {
        
    }
    
}
