
package aula03ex2;

import java.util.Scanner;


public class ContaCorrente {
    String nome;
    float saldo;
    float limite;
    char tipo;
    
    public ContaCorrente(){
        
    }
    
    public ContaCorrente(String n, float s, float l, char t){
        this.nome = n;
        this.saldo = s;
        this.limite = l;
        this.tipo = t;
    }
    
    public ContaCorrente(String n, float s, char t){
        this.nome = n;
        this.saldo = s;
        this.tipo = t;
    }
    
    public void cadastraDados(){
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Digite o seu nome: ");
        this.nome = teclado.nextLine();
        System.out.print("Digite seu saldo: ");
        this.saldo = teclado.nextFloat();
        System.out.print("Digite o limite da sua conta: ");
        this.limite = teclado.nextFloat();
        System.out.print("Digite o tipo da sua conta: ");
        this.tipo = teclado.next().charAt(0);
    }
    
    public String imprimeDados(){
        return "Dados: \nNome: " + this.nome + "\nSaldo: " + this.saldo + "\nLimite: "
                + this.limite + "\nTipo: " + this.tipo;
    }
    
    public void depositar(float valor){
        this.saldo += valor;
    }
    
    public void sacar(float valor){
        this.saldo -= valor;
               
    }
            
}
