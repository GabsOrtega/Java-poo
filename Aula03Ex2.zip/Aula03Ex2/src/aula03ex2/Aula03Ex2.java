
package aula03ex2;


public class Aula03Ex2 {

    public static void main(String[] args) {
       ContaCorrente c = new ContaCorrente("Ortega", 2000f, 5000f, '1');
       ContaCorrente c2 = new ContaCorrente();
       
       c.imprimeDados();
       c.depositar(30);
       System.out.println(c.imprimeDados());
       c.sacar(50);
       System.out.println(c.imprimeDados());
       
       c2.cadastraDados();
       System.out.println(c2.imprimeDados());
       c2.depositar(100);
       System.out.println(c2.imprimeDados());
       c2.sacar(40);
       System.out.println(c2.imprimeDados());
       
       
       
       
    }
    
}
