
package aula03ex2;


public class Aula03Ex2 {

    public static void main(String[] args) {
       
    }
    
}
