
package aula0601;
import java.lang.Math;


public class Circunferencia extends Forma {
    private float raio;

    public Circunferencia(float r) {
        this.raio = r;
    }
    
    public void setCircunferencia(float r){
        this.raio = r;
    }
    
    public float getCircunferencia(){
        return this.raio;
    }

    @Override
    public float area() {
        float area = (float) (Math.PI * Math.pow(this.raio, 2));
        return area;
    }

    @Override
    public void mostra() {
        System.out.println("Circunferência");
        System.out.println("Raio: " + this.raio);
        System.out.println("Area: " + this.area());
        System.out.println("Perimetro: " + this.perimetro());
    }

    public float perimetro() {
        float perimetro = (float) (2 * Math.PI * this.raio);
        return perimetro;
    }
    
    
    
    
}
